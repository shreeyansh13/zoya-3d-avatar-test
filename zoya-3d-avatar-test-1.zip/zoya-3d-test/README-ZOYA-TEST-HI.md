# Zoya 3D Avatar — अलग टेस्ट प्रोजेक्ट

यह Anima के सार्वजनिक frontend पर आधारित अलग परीक्षण प्रोजेक्ट है। इसमें VRM 3D मॉडल और स्थानीय motion assets हैं। Studio स्क्रीन का framing अधिक zoomed किया गया है ताकि मोबाइल पर avatar बड़ा दिखे।

## जरूरी सीमा
- यह अभी Zoya की लाइव वेबसाइट में deploy या connect नहीं किया गया है।
- इसका Chat/Voice अभी Anima के अपने API/backend पर निर्भर हो सकता है। यह Zoya के Gemini `/chat` से जुड़ा नहीं है।
- Zoya backend का `server.js`, Gemini API key और Android Call Flow इस प्रोजेक्ट में न बदलें।
- पहले 3D मॉडल/framing का परीक्षण करें; फिर अलग चरण में `/chat` integration करें।

## कंप्यूटर पर टेस्ट
1. Node.js 20+ स्थापित करें।
2. इस folder में terminal खोलें।
3. `npm install` चलाएँ।
4. `npm run dev -- --host 0.0.0.0` चलाएँ।
5. terminal में दिखा local URL खोलें और Characters → Mio/Studio खोलें।

## Render पर deploy करने से पहले
यह Vite/React frontend है, मौजूदा static `index.html` नहीं। इसे Zoya की मौजूदा Static Site पर सीधे डालने से पहले build/deploy configuration और backend dependencies की जाँच आवश्यक है।

## Assets
`ASSET_LICENSE.md` में sample VRM characters और motions के license notes देखें।
